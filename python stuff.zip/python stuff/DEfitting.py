# -*- coding: utf-8 -*-
"""
Created on Tue Sep 15 13:11:33 2015

@author: Austin
"""
Simultaneous equations
Himmelblau's function
rosenbrock's function

#talk more about the ps3 algorithm...
#
#slide 2
#
#Himmelblau function test performance
#- test with sum of squares
#	-always positive
#	
#
#	
#	
#four minima and one maxima
#	-difficult to find all 5 of these
#
#objective function either minimized or maximized (least squares)
#	-we are going to do one at a time (min and max)
#
#	
#Himmelblau function
#
#subroutine fit(b,value) !fitness of vectors
#dimension b(2)
#value= sum of squares
#end
#
#f(x,y)=function 
#b(1)=x
#b(2)=y

# gradient finds nearest pothol and isnot good for multiple max and min


b=[]
def fit(b,value): #fitness of vectors
# define array with two variables

value= sum of squares
end

f(x,y)=function 
b(1)=x
b(2)=y


# in order to address requirements on slide 3 you need a large population
# this is to give a diversity of solutions
# needs a small weighting factor
#if not we find the largest tree in the forest, we want smallest and largest


# you need small weighting factor....


#slide 4 

#larger weighting and corssover miss solutions

#Rosenbrock's banan function
#
#f(x,y)= (a-x)^2 + b(y-x^2)^2
#b=100
#a=1





