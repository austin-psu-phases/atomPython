# -*- coding: utf-8 -*-
"""
Created on Tue Sep 15 14:30:29 2015

@author: ajr335
"""

print("yes")